<?php
// Configuration file - Keep this file secure!
// DO NOT commit this file to version control

// OpenRouter API Key
define('OPENROUTER_API_KEY', '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');

// TomTom API Key
define('TOMTOM_API_KEY', 'ad6D4bTm8n9Z1f8Hv9HYhdINHi7fSOgA');

// Optional: Add other configuration settings here
define('API_TIMEOUT', 30); // seconds
define('MAX_TOKENS', 500);
?>